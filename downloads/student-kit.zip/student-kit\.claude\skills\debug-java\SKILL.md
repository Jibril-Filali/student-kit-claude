---
name: debug-java
description: Analyse et corrige une erreur Java. Utiliser quand tu as une exception, un stack trace ou un comportement inattendu.
---

# Debug Java

## Process

1. Lire le stack trace complet de haut en bas
2. Identifier la ligne exacte qui a causé l'erreur
3. Comprendre le TYPE d'erreur :
   - `NullPointerException` → un objet est null là où on ne s'y attendait pas
   - `ClassCastException` → mauvaise conversion de type
   - `ArrayIndexOutOfBoundsException` → on dépasse la taille du tableau
   - `SQLException` → problème avec la requête SQL ou la connexion
   - `NumberFormatException` → conversion de String en nombre impossible
   - `StackOverflowError` → récursion infinie
4. Trouver la cause racine — pas juste le symptôme
5. Corriger et expliquer pourquoi c'était cassé

## Règles
- Toujours expliquer CE QUI causait le bug, pas juste montrer le fix
- Si la correction cache le problème plutôt que le résoudre : le dire
- Vérifier que le fix ne crée pas un autre bug
- Ajouter l'erreur dans tasks/lessons.md après correction
