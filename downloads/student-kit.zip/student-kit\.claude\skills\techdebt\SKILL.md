---
name: techdebt
description: Analyse le code pour identifier et lister la dette technique. Utiliser en fin de session ou avant une refonte.
---

# Analyse de dette technique

## Objectif
Identifier ce qui ralentit le développement ou crée des risques, et produire une liste priorisée.

## Process

1. Scanner les fichiers modifiés récemment et les zones critiques
2. Identifier les problèmes par catégorie :

### Code
- Fonctions trop longues (>50 lignes)
- Duplication de logique
- Nommage ambigu
- Commentaires manquants sur logique complexe

### Architecture
- Composants qui font trop de choses
- Couplage fort entre modules
- Appels API directement dans les composants
- State management incohérent

### Tests
- Code non testé dans les zones critiques
- Tests fragiles qui cassent souvent

### Dépendances
- Packages outdatés avec vulnérabilités connues
- Dépendances inutilisées

## Output attendu
Liste priorisée : 🔴 critique (bloque ou risque sécurité) | 🟠 important | 🟡 mineur
Pour chaque item : fichier concerné + description courte + effort estimé (S/M/L)
