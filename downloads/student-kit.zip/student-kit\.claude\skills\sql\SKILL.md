---
name: sql
description: Aide avec les requêtes MySQL — écrire, corriger, optimiser. Utiliser pour tout ce qui touche à la base de données MySQL.
---

# Aide SQL / MySQL

## Ce que tu peux demander
- Écrire une requête depuis zéro
- Corriger une requête qui ne marche pas
- Expliquer pourquoi une requête est lente
- Créer un schéma de tables
- Écrire des jointures complexes

## Process

1. Comprendre ce que la requête doit retourner
2. Identifier les tables et relations impliquées
3. Écrire la requête étape par étape
4. Expliquer chaque partie

## Règles absolues
- Toujours utiliser des PreparedStatement en Java — jamais de concaténation de String pour les requêtes
- Toujours tester avec un petit jeu de données d'abord
- Expliquer les JOIN utilisés (INNER, LEFT, RIGHT) et pourquoi
- Signaler si une requête risque d'être lente sur de gros volumes

## Format de réponse
```sql
-- Explication de ce que fait la requête
SELECT ...
FROM ...
JOIN ...
WHERE ...
```
Puis explication ligne par ligne si la requête est complexe.
