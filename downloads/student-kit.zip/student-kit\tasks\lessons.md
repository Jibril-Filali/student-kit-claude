# Lessons

> Chaque erreur corrigée est ajoutée ici pour ne jamais être répétée.
> Format : [date] | ce qui a mal tourné | règle pour l'éviter

## Erreurs apprises
<!-- Claude remplit cette section au fil des sessions -->
