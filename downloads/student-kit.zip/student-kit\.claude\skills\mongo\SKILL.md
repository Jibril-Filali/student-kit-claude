---
name: mongo
description: Aide avec MongoDB — requêtes, agrégations, schémas. Utiliser pour tout ce qui touche à MongoDB.
---

# Aide MongoDB

## Ce que tu peux demander
- Écrire une requête find() ou aggregate()
- Créer un schéma de collection
- Corriger une requête qui ne retourne pas ce qu'on attend
- Comprendre les agrégations ($match, $group, $lookup)
- Convertir une requête SQL en MongoDB

## Process

1. Comprendre ce que la requête doit retourner
2. Identifier la collection et la structure des documents
3. Écrire la requête avec explication
4. Proposer un index si pertinent

## Format de réponse
```javascript
// Explication
db.maCollection.find({
  champ: valeur
})
```
Puis explication de chaque opérateur utilisé.

## Règles
- Toujours valider la structure d'un document avant insertion
- Expliquer la différence avec SQL quand c'est utile
- Signaler quand une agrégation serait plus efficace qu'une boucle en Java
- Proposer des index sur les champs utilisés dans les filtres
