# Todo

## En cours
<!-- Claude remplit cette section avec le plan de la tâche en cours -->

## À faire
<!-- Prochaines tâches -->

## Terminé
<!-- Tâches complétées -->
