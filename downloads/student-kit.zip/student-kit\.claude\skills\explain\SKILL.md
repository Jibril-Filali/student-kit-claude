---
name: explain
description: Explique un concept de cours, un bout de code ou un sujet de TP. Utiliser quand tu ne comprends pas quelque chose.
---

# Explication de concept

## Process

1. Identifier ce qui est demandé (concept théorique, bout de code, exercice)
2. Expliquer en 3 niveaux :
   - **En une phrase** : l'idée centrale
   - **Avec une analogie** : comparer à quelque chose du quotidien
   - **Avec un exemple de code** : concret et minimal

3. Vérifier la compréhension : poser une question simple à la fin pour s'assurer que c'est compris

## Exemples de ce que tu peux demander
- "explique moi ce que fait ce code"
- "c'est quoi une jointure SQL"
- "je comprends pas l'héritage en Java"
- "c'est quoi un index en base de données"
- "explique moi ce TP"

## Règles
- Pas de jargon sans l'expliquer
- Toujours un exemple concret — jamais juste de la théorie
- Si le concept est complexe : le découper en plusieurs étapes
- Adapter le niveau à celui de l'étudiant
