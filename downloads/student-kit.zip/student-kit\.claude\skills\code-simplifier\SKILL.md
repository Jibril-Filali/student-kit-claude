---
name: simplify
description: Simplifie un bloc de code complexe sans changer son comportement. Utiliser quand le code est trop long, trop imbriqué ou difficile à lire.
---

# Simplification de code

## Objectif
Rendre le code plus lisible et maintenable sans changer son comportement observable.

## Process

1. Lire et comprendre ce que fait le code actuellement
2. Identifier les complexités inutiles :
   - Imbrications profondes (if dans if dans if)
   - Variables intermédiaires inutiles
   - Logique dupliquée
   - Conditions inversées difficiles à lire
3. Proposer une version simplifiée
4. Vérifier que le comportement est identique
5. Lancer les tests si disponibles

## Techniques à appliquer
- Early return plutôt que else imbriqués
- Optional chaining (`?.`) et nullish coalescing (`??`)
- Destructuring pour les objets et tableaux
- Array methods (map, filter, reduce) plutôt que boucles impératives
- Extraire les fonctions helpers si un bloc se répète

## Règle absolue
Ne jamais changer le comportement observable pour simplifier. Si un bug est trouvé en chemin, le signaler séparément.
