---
name: commit-push-pr
description: Crée un commit propre, pousse la branche et ouvre une PR. Utiliser quand le travail est terminé et prêt à merger.
---

# Commit, push et PR

## Étapes

1. Vérifier le statut git — lister tous les fichiers modifiés
2. Grouper les changements en commits logiques (un commit = un sujet)
3. Écrire des messages de commit clairs au format : `type(scope): description courte`
   - Types : feat, fix, refactor, style, test, docs, chore
   - Exemple : `feat(auth): add JWT refresh token logic`
4. Pousser la branche sur le remote
5. Créer la PR avec :
   - Titre clair résumant le changement principal
   - Description avec : contexte, ce qui a changé, comment tester
   - Lier les issues concernées si applicable

## Règles
- Ne jamais commit les fichiers .env ou secrets
- Ne jamais forcer un push sur main/master
- Un commit ne doit jamais mélanger refactoring et nouvelle feature
